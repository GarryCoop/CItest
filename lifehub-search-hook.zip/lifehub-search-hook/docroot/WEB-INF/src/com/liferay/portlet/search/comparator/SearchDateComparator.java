package com.liferay.portlet.search.comparator;

import com.liferay.portal.kernel.dao.search.ResultRow;
import com.liferay.portal.kernel.dao.search.TextSearchEntry;
import com.liferay.portal.kernel.util.DateUtil;
import com.liferay.portal.kernel.util.OrderByComparator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SearchDateComparator extends OrderByComparator {

	public static String ORDER_BY_ASC = "UPLOADED ASC";

	public static String ORDER_BY_DESC = "UPLOADED DESC";

	public static String[] ORDER_BY_FIELDS = {"UPLOADED"};
	
	private static SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yy, HH:mm");
	
	public SearchDateComparator(){
		this(false);
	}

	public SearchDateComparator(boolean ascending) {
		_ascending = ascending;
	}

	@Override
	public int compare(Object arg0, Object arg1) {
		ResultRow rr1=(ResultRow)arg0;
		ResultRow rr2=(ResultRow)arg1;
		
		TextSearchEntry tse1=(TextSearchEntry)rr1.getEntries().get(2);
		TextSearchEntry tse2=(TextSearchEntry)rr2.getEntries().get(2);
		
		String name1=tse1.getName();
		String name2=tse2.getName();
		
		int value=0;
		try {
			Date date1=sdf.parse(name1);
			Date date2=sdf.parse(name2);
			
			value = DateUtil.compareTo(date1, date2);
		} catch (ParseException e) {
			value=0;
		}

		if (_ascending) {
			return value;
		}
		else {
			return -value;
		}
	}

	public String getOrderBy() {
		if (_ascending) {
			return ORDER_BY_ASC;
		}
		else {
			return ORDER_BY_DESC;
		}
	}

	public String[] getOrderByFields() {
		return ORDER_BY_FIELDS;
	}

	public boolean isAscending() {
		return _ascending;
	}

	private boolean _ascending;

}
