package com.liferay.portlet.search.comparator;

import com.liferay.portal.kernel.util.OrderByComparator;

public class SearchComparatorUtil {

	public static OrderByComparator getItemOrderByComparator(String orderByCol, String orderByType) {
		boolean orderByAsc = false;

		if (orderByType.equals("asc")) {
			orderByAsc = true;
		}

		OrderByComparator orderByComparator = null;

		if (orderByCol.equals("DOCUMENT")) {
			orderByComparator = new SearchNameComparator(orderByAsc);
		}
		else if (orderByCol.equals("UPLOADED")) {
			orderByComparator = new SearchDateComparator(orderByAsc);
		}

		return orderByComparator;
	}
}
