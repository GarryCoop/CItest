package com.liferay.portlet.search.comparator;

import com.liferay.portal.kernel.dao.search.ResultRow;
import com.liferay.portal.kernel.dao.search.TextSearchEntry;
import com.liferay.portal.kernel.util.OrderByComparator;

public class SearchNameComparator extends OrderByComparator {

	public static String ORDER_BY_ASC = "DOCUMENT ASC";

	public static String ORDER_BY_DESC = "DOCUMENT DESC";

	public static String[] ORDER_BY_FIELDS = {"DOCUMENT"};
	
	public SearchNameComparator(){
		this(false);
	}

	public SearchNameComparator(boolean ascending) {
		_ascending = ascending;
	}

	@Override
	public int compare(Object arg0, Object arg1) {
		ResultRow rr1=(ResultRow)arg0;
		ResultRow rr2=(ResultRow)arg1;
		
		TextSearchEntry tse1=(TextSearchEntry)rr1.getEntries().get(2);
		TextSearchEntry tse2=(TextSearchEntry)rr2.getEntries().get(2);
		
		String name1=tse1.getName();
		String name2=tse2.getName();
		
		int value = name1.toLowerCase().compareTo(name2.toLowerCase());

		if (_ascending) {
			return value;
		}
		else {
			return -value;
		}
	}

	public String getOrderBy() {
		if (_ascending) {
			return ORDER_BY_ASC;
		}
		else {
			return ORDER_BY_DESC;
		}
	}

	public String[] getOrderByFields() {
		return ORDER_BY_FIELDS;
	}

	public boolean isAscending() {
		return _ascending;
	}

	private boolean _ascending;

}
